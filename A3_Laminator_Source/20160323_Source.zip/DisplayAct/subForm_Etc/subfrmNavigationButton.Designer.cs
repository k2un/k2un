﻿namespace DisplayAct
{
    partial class subfrmNavigationButton
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(subfrmNavigationButton));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnSetupView = new System.Windows.Forms.Button();
            this.btnHistoryView = new System.Windows.Forms.Button();
            this.btnMainView = new System.Windows.Forms.Button();
            this.btnInfoView = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Controls.Add(this.btnInfoView, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnSetupView, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnHistoryView, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnMainView, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(929, 48);
            this.tableLayoutPanel1.TabIndex = 47;
            // 
            // btnSetupView
            // 
            this.btnSetupView.BackColor = System.Drawing.Color.Black;
            this.btnSetupView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSetupView.BackgroundImage")));
            this.btnSetupView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSetupView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSetupView.FlatAppearance.BorderSize = 0;
            this.btnSetupView.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnSetupView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSetupView.Image = ((System.Drawing.Image)(resources.GetObject("btnSetupView.Image")));
            this.btnSetupView.Location = new System.Drawing.Point(463, 1);
            this.btnSetupView.Margin = new System.Windows.Forms.Padding(1);
            this.btnSetupView.Name = "btnSetupView";
            this.btnSetupView.Size = new System.Drawing.Size(152, 46);
            this.btnSetupView.TabIndex = 51;
            this.btnSetupView.Text = "Setup View";
            this.btnSetupView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSetupView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSetupView.UseVisualStyleBackColor = false;
            this.btnSetupView.Click += new System.EventHandler(this.btnSetupView_Click);
            // 
            // btnHistoryView
            // 
            this.btnHistoryView.BackColor = System.Drawing.Color.Black;
            this.btnHistoryView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHistoryView.BackgroundImage")));
            this.btnHistoryView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHistoryView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHistoryView.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnHistoryView.FlatAppearance.BorderSize = 0;
            this.btnHistoryView.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnHistoryView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnHistoryView.Image = ((System.Drawing.Image)(resources.GetObject("btnHistoryView.Image")));
            this.btnHistoryView.Location = new System.Drawing.Point(155, 1);
            this.btnHistoryView.Margin = new System.Windows.Forms.Padding(1);
            this.btnHistoryView.Name = "btnHistoryView";
            this.btnHistoryView.Size = new System.Drawing.Size(152, 46);
            this.btnHistoryView.TabIndex = 49;
            this.btnHistoryView.Text = "History View";
            this.btnHistoryView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnHistoryView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHistoryView.UseVisualStyleBackColor = false;
            this.btnHistoryView.Click += new System.EventHandler(this.btnHistoryView_Click);
            // 
            // btnMainView
            // 
            this.btnMainView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMainView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMainView.BackgroundImage")));
            this.btnMainView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMainView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMainView.FlatAppearance.BorderSize = 0;
            this.btnMainView.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnMainView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMainView.Image = ((System.Drawing.Image)(resources.GetObject("btnMainView.Image")));
            this.btnMainView.Location = new System.Drawing.Point(1, 1);
            this.btnMainView.Margin = new System.Windows.Forms.Padding(1);
            this.btnMainView.Name = "btnMainView";
            this.btnMainView.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.btnMainView.Size = new System.Drawing.Size(152, 46);
            this.btnMainView.TabIndex = 48;
            this.btnMainView.Text = "Main View";
            this.btnMainView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMainView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMainView.UseVisualStyleBackColor = false;
            this.btnMainView.Click += new System.EventHandler(this.btnMainView_Click);
            // 
            // btnInfoView
            // 
            this.btnInfoView.BackColor = System.Drawing.Color.Black;
            this.btnInfoView.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInfoView.BackgroundImage")));
            this.btnInfoView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInfoView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnInfoView.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnInfoView.FlatAppearance.BorderSize = 0;
            this.btnInfoView.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold);
            this.btnInfoView.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnInfoView.Image = global::DisplayAct.Properties.Resources.main;
            this.btnInfoView.Location = new System.Drawing.Point(309, 1);
            this.btnInfoView.Margin = new System.Windows.Forms.Padding(1);
            this.btnInfoView.Name = "btnInfoView";
            this.btnInfoView.Size = new System.Drawing.Size(152, 46);
            this.btnInfoView.TabIndex = 52;
            this.btnInfoView.Text = "Info View";
            this.btnInfoView.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnInfoView.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnInfoView.UseVisualStyleBackColor = false;
            this.btnInfoView.Click += new System.EventHandler(this.btnInfoView_Click);
            // 
            // subfrmNavigationButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "subfrmNavigationButton";
            this.Size = new System.Drawing.Size(929, 48);
            this.Load += new System.EventHandler(this.subfrmOperationButton_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnMainView;
        private System.Windows.Forms.Button btnSetupView;
        private System.Windows.Forms.Button btnHistoryView;
        private System.Windows.Forms.Button btnInfoView;
    }
}
