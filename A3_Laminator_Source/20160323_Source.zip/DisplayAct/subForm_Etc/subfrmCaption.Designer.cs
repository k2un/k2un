﻿namespace DisplayAct
{
    partial class subfrmCaption
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblSEMState = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblEQPPPID = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblEQPProcessState = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblHostConnection = new System.Windows.Forms.Label();
            this.lblPLCConnection = new System.Windows.Forms.Label();
            this.lblHOSTDriver = new System.Windows.Forms.Label();
            this.lblControlState = new System.Windows.Forms.Label();
            this.cboHostMessage = new System.Windows.Forms.ComboBox();
            this.btnHostMessageClear = new System.Windows.Forms.Button();
            this.lblHOSTPPID = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblEQPState = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tmrUpdateCaption = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblSEMState, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblEQPPPID, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblEQPProcessState, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblHostConnection, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblPLCConnection, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblHOSTDriver, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblControlState, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.cboHostMessage, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnHostMessageClear, 9, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblHOSTPPID, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.label11, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblEQPState, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1018, 80);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.SystemColors.InfoText;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(0, 55);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 25);
            this.label9.TabIndex = 77;
            this.label9.Text = "Host Message";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.SystemColors.InfoText;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 20);
            this.label4.TabIndex = 76;
            this.label4.Text = "Host Connection";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.SystemColors.InfoText;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(122, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 20);
            this.label2.TabIndex = 75;
            this.label2.Text = "PLC Connection";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.SystemColors.InfoText;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(244, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 74;
            this.label1.Text = "Host DRV";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSEMState
            // 
            this.lblSEMState.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSEMState.BackColor = System.Drawing.Color.Red;
            this.lblSEMState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSEMState.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSEMState.ForeColor = System.Drawing.Color.White;
            this.lblSEMState.Location = new System.Drawing.Point(681, 20);
            this.lblSEMState.Margin = new System.Windows.Forms.Padding(0);
            this.lblSEMState.Name = "lblSEMState";
            this.lblSEMState.Size = new System.Drawing.Size(91, 35);
            this.lblSEMState.TabIndex = 73;
            this.lblSEMState.Text = "Diconnected";
            this.lblSEMState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.SystemColors.InfoText;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(681, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 72;
            this.label8.Text = "SEM";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEQPPPID
            // 
            this.lblEQPPPID.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEQPPPID.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblEQPPPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEQPPPID.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEQPPPID.Location = new System.Drawing.Point(914, 20);
            this.lblEQPPPID.Margin = new System.Windows.Forms.Padding(0);
            this.lblEQPPPID.Name = "lblEQPPPID";
            this.lblEQPPPID.Size = new System.Drawing.Size(104, 35);
            this.lblEQPPPID.TabIndex = 71;
            this.lblEQPPPID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.SystemColors.InfoText;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(914, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 20);
            this.label5.TabIndex = 70;
            this.label5.Text = "EQP PPID";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.SystemColors.InfoText;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(559, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 20);
            this.label6.TabIndex = 69;
            this.label6.Text = "Process State";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEQPProcessState
            // 
            this.lblEQPProcessState.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEQPProcessState.BackColor = System.Drawing.Color.Red;
            this.lblEQPProcessState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEQPProcessState.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEQPProcessState.ForeColor = System.Drawing.Color.White;
            this.lblEQPProcessState.Location = new System.Drawing.Point(559, 20);
            this.lblEQPProcessState.Margin = new System.Windows.Forms.Padding(0);
            this.lblEQPProcessState.Name = "lblEQPProcessState";
            this.lblEQPProcessState.Size = new System.Drawing.Size(122, 35);
            this.lblEQPProcessState.TabIndex = 68;
            this.lblEQPProcessState.Text = "Disabled";
            this.lblEQPProcessState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.SystemColors.InfoText;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(315, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 20);
            this.label3.TabIndex = 43;
            this.label3.Text = "Control State";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHostConnection
            // 
            this.lblHostConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHostConnection.BackColor = System.Drawing.Color.Red;
            this.lblHostConnection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHostConnection.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHostConnection.ForeColor = System.Drawing.Color.White;
            this.lblHostConnection.Location = new System.Drawing.Point(0, 20);
            this.lblHostConnection.Margin = new System.Windows.Forms.Padding(0);
            this.lblHostConnection.Name = "lblHostConnection";
            this.lblHostConnection.Size = new System.Drawing.Size(122, 35);
            this.lblHostConnection.TabIndex = 49;
            this.lblHostConnection.Text = "Disconnect";
            this.lblHostConnection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPLCConnection
            // 
            this.lblPLCConnection.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPLCConnection.BackColor = System.Drawing.Color.Red;
            this.lblPLCConnection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPLCConnection.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPLCConnection.ForeColor = System.Drawing.Color.White;
            this.lblPLCConnection.Location = new System.Drawing.Point(122, 20);
            this.lblPLCConnection.Margin = new System.Windows.Forms.Padding(0);
            this.lblPLCConnection.Name = "lblPLCConnection";
            this.lblPLCConnection.Size = new System.Drawing.Size(122, 35);
            this.lblPLCConnection.TabIndex = 50;
            this.lblPLCConnection.Text = "Disconnect";
            this.lblPLCConnection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHOSTDriver
            // 
            this.lblHOSTDriver.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHOSTDriver.BackColor = System.Drawing.Color.Red;
            this.lblHOSTDriver.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHOSTDriver.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHOSTDriver.ForeColor = System.Drawing.Color.White;
            this.lblHOSTDriver.Location = new System.Drawing.Point(244, 20);
            this.lblHOSTDriver.Margin = new System.Windows.Forms.Padding(0);
            this.lblHOSTDriver.Name = "lblHOSTDriver";
            this.lblHOSTDriver.Size = new System.Drawing.Size(71, 35);
            this.lblHOSTDriver.TabIndex = 51;
            this.lblHOSTDriver.Text = "NO";
            this.lblHOSTDriver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblControlState
            // 
            this.lblControlState.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblControlState.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblControlState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblControlState.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControlState.Location = new System.Drawing.Point(315, 20);
            this.lblControlState.Margin = new System.Windows.Forms.Padding(0);
            this.lblControlState.Name = "lblControlState";
            this.lblControlState.Size = new System.Drawing.Size(122, 35);
            this.lblControlState.TabIndex = 54;
            this.lblControlState.Text = "OFFLINE";
            this.lblControlState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboHostMessage
            // 
            this.cboHostMessage.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.SetColumnSpan(this.cboHostMessage, 8);
            this.cboHostMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboHostMessage.DropDownHeight = 150;
            this.cboHostMessage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHostMessage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboHostMessage.FormattingEnabled = true;
            this.cboHostMessage.IntegralHeight = false;
            this.cboHostMessage.ItemHeight = 16;
            this.cboHostMessage.Location = new System.Drawing.Point(123, 56);
            this.cboHostMessage.Margin = new System.Windows.Forms.Padding(1);
            this.cboHostMessage.MaxDropDownItems = 15;
            this.cboHostMessage.Name = "cboHostMessage";
            this.cboHostMessage.Size = new System.Drawing.Size(790, 24);
            this.cboHostMessage.TabIndex = 62;
            // 
            // btnHostMessageClear
            // 
            this.btnHostMessageClear.BackColor = System.Drawing.Color.DimGray;
            this.btnHostMessageClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHostMessageClear.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHostMessageClear.ForeColor = System.Drawing.Color.White;
            this.btnHostMessageClear.Location = new System.Drawing.Point(914, 55);
            this.btnHostMessageClear.Margin = new System.Windows.Forms.Padding(0);
            this.btnHostMessageClear.Name = "btnHostMessageClear";
            this.btnHostMessageClear.Size = new System.Drawing.Size(104, 25);
            this.btnHostMessageClear.TabIndex = 64;
            this.btnHostMessageClear.Text = "Clear";
            this.btnHostMessageClear.UseVisualStyleBackColor = false;
            this.btnHostMessageClear.Click += new System.EventHandler(this.btnHostMessageClear_Click);
            // 
            // lblHOSTPPID
            // 
            this.lblHOSTPPID.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHOSTPPID.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblHOSTPPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.lblHOSTPPID, 2);
            this.lblHOSTPPID.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHOSTPPID.Location = new System.Drawing.Point(772, 20);
            this.lblHOSTPPID.Margin = new System.Windows.Forms.Padding(0);
            this.lblHOSTPPID.Name = "lblHOSTPPID";
            this.lblHOSTPPID.Size = new System.Drawing.Size(142, 35);
            this.lblHOSTPPID.TabIndex = 57;
            this.lblHOSTPPID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.BackColor = System.Drawing.SystemColors.InfoText;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.label11, 2);
            this.label11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Control;
            this.label11.Location = new System.Drawing.Point(772, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 20);
            this.label11.TabIndex = 46;
            this.label11.Text = "HOST PPID";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEQPState
            // 
            this.lblEQPState.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEQPState.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblEQPState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEQPState.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEQPState.Location = new System.Drawing.Point(437, 20);
            this.lblEQPState.Margin = new System.Windows.Forms.Padding(0);
            this.lblEQPState.Name = "lblEQPState";
            this.lblEQPState.Size = new System.Drawing.Size(122, 35);
            this.lblEQPState.TabIndex = 55;
            this.lblEQPState.Text = "NORMAL";
            this.lblEQPState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.SystemColors.InfoText;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(437, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 20);
            this.label7.TabIndex = 44;
            this.label7.Text = "EQP State";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmrUpdateCaption
            // 
            this.tmrUpdateCaption.Interval = 1000;
            this.tmrUpdateCaption.Tick += new System.EventHandler(this.tmrUpdateCaption_Tick);
            // 
            // subfrmCaption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "subfrmCaption";
            this.Size = new System.Drawing.Size(1018, 80);
            this.Load += new System.EventHandler(this.subfrmCaption_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.Label label11;
        internal System.Windows.Forms.Label lblControlState;
        internal System.Windows.Forms.Label lblEQPState;
        internal System.Windows.Forms.Label lblHOSTPPID;
        public System.Windows.Forms.ComboBox cboHostMessage;
        internal System.Windows.Forms.Button btnHostMessageClear;
        private System.Windows.Forms.Timer tmrUpdateCaption;
        internal System.Windows.Forms.Label lblHostConnection;
        internal System.Windows.Forms.Label lblPLCConnection;
        internal System.Windows.Forms.Label lblHOSTDriver;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label lblEQPProcessState;
        internal System.Windows.Forms.Label lblEQPPPID;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label lblSEMState;
        internal System.Windows.Forms.Label label8;
        internal System.Windows.Forms.Label label9;
    }
}
