﻿namespace DisplayAct
{
    partial class tabfrmSetupEQP
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtUnitCount = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtSlotCount = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtMDLN = new System.Windows.Forms.TextBox();
            this.txtEQPID = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblLastModified = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCimBitInitial = new System.Windows.Forms.Button();
            this.txtKeepDays = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnFTP = new System.Windows.Forms.Button();
            this.groupBox6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtUnitCount);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.txtSlotCount);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.txtMDLN);
            this.groupBox6.Controls.Add(this.txtEQPID);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(8, 45);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(324, 441);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "EQP Information";
            // 
            // txtUnitCount
            // 
            this.txtUnitCount.BackColor = System.Drawing.Color.White;
            this.txtUnitCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUnitCount.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtUnitCount.Enabled = false;
            this.txtUnitCount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnitCount.Location = new System.Drawing.Point(16, 215);
            this.txtUnitCount.Name = "txtUnitCount";
            this.txtUnitCount.ReadOnly = true;
            this.txtUnitCount.Size = new System.Drawing.Size(198, 19);
            this.txtUnitCount.TabIndex = 57;
            this.txtUnitCount.Text = "19";
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.Gainsboro;
            this.label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(10, 207);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(220, 2);
            this.label29.TabIndex = 58;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Gainsboro;
            this.label30.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(10, 187);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(169, 21);
            this.label30.TabIndex = 56;
            this.label30.Text = " Unit Count";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSlotCount
            // 
            this.txtSlotCount.BackColor = System.Drawing.Color.White;
            this.txtSlotCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSlotCount.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtSlotCount.Enabled = false;
            this.txtSlotCount.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSlotCount.Location = new System.Drawing.Point(17, 160);
            this.txtSlotCount.Name = "txtSlotCount";
            this.txtSlotCount.ReadOnly = true;
            this.txtSlotCount.Size = new System.Drawing.Size(198, 19);
            this.txtSlotCount.TabIndex = 55;
            this.txtSlotCount.Text = "25";
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.Gainsboro;
            this.label35.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(10, 151);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(220, 2);
            this.label35.TabIndex = 54;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.Gainsboro;
            this.label36.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(10, 131);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(169, 21);
            this.label36.TabIndex = 53;
            this.label36.Text = " Slot Count";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMDLN
            // 
            this.txtMDLN.BackColor = System.Drawing.Color.White;
            this.txtMDLN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMDLN.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMDLN.Location = new System.Drawing.Point(17, 109);
            this.txtMDLN.Name = "txtMDLN";
            this.txtMDLN.Size = new System.Drawing.Size(198, 19);
            this.txtMDLN.TabIndex = 48;
            this.txtMDLN.Text = "Etch";
            // 
            // txtEQPID
            // 
            this.txtEQPID.BackColor = System.Drawing.Color.White;
            this.txtEQPID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEQPID.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEQPID.Location = new System.Drawing.Point(17, 59);
            this.txtEQPID.Name = "txtEQPID";
            this.txtEQPID.Size = new System.Drawing.Size(198, 19);
            this.txtEQPID.TabIndex = 40;
            this.txtEQPID.Text = "EQPID";
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Gainsboro;
            this.label41.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(10, 101);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(220, 2);
            this.label41.TabIndex = 40;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Gainsboro;
            this.label42.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(10, 81);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(169, 21);
            this.label42.TabIndex = 39;
            this.label42.Text = " MDLN";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.Gainsboro;
            this.label37.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(10, 50);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(220, 2);
            this.label37.TabIndex = 36;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.Gainsboro;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(10, 30);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(169, 21);
            this.label38.TabIndex = 35;
            this.label38.Text = " EQP ID";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "Last Modified : ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLastModified
            // 
            this.lblLastModified.BackColor = System.Drawing.Color.DarkCyan;
            this.lblLastModified.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblLastModified.ForeColor = System.Drawing.Color.White;
            this.lblLastModified.Location = new System.Drawing.Point(143, 8);
            this.lblLastModified.Name = "lblLastModified";
            this.lblLastModified.Size = new System.Drawing.Size(188, 30);
            this.lblLastModified.TabIndex = 4;
            this.lblLastModified.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFTP);
            this.groupBox1.Controls.Add(this.btnCimBitInitial);
            this.groupBox1.Controls.Add(this.txtKeepDays);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(338, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(324, 441);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Process Data Information";
            // 
            // btnCimBitInitial
            // 
            this.btnCimBitInitial.Location = new System.Drawing.Point(6, 392);
            this.btnCimBitInitial.Name = "btnCimBitInitial";
            this.btnCimBitInitial.Size = new System.Drawing.Size(312, 43);
            this.btnCimBitInitial.TabIndex = 66;
            this.btnCimBitInitial.Text = "Cim Event Bit Initial";
            this.btnCimBitInitial.UseVisualStyleBackColor = true;
            this.btnCimBitInitial.Click += new System.EventHandler(this.btnCimBitInitial_Click);
            // 
            // txtKeepDays
            // 
            this.txtKeepDays.BackColor = System.Drawing.Color.White;
            this.txtKeepDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKeepDays.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeepDays.Location = new System.Drawing.Point(12, 84);
            this.txtKeepDays.Name = "txtKeepDays";
            this.txtKeepDays.Size = new System.Drawing.Size(198, 19);
            this.txtKeepDays.TabIndex = 64;
            this.txtKeepDays.Text = "7";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Gainsboro;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 2);
            this.label2.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Gainsboro;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 47);
            this.label3.TabIndex = 63;
            this.label3.Text = " Process Data\r\n Days to keep";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnFTP
            // 
            this.btnFTP.Location = new System.Drawing.Point(6, 343);
            this.btnFTP.Name = "btnFTP";
            this.btnFTP.Size = new System.Drawing.Size(312, 43);
            this.btnFTP.TabIndex = 67;
            this.btnFTP.Text = "FTP 통신 확인";
            this.btnFTP.UseVisualStyleBackColor = true;
            this.btnFTP.Click += new System.EventHandler(this.btnFTP_Click);
            // 
            // tabfrmSetupEQP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblLastModified);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox6);
            this.Name = "tabfrmSetupEQP";
            this.Size = new System.Drawing.Size(928, 550);
            this.Load += new System.EventHandler(this.tabfrmSetupEQPInfo_Load);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtUnitCount;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtSlotCount;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtMDLN;
        private System.Windows.Forms.TextBox txtEQPID;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblLastModified;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtKeepDays;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCimBitInitial;
        private System.Windows.Forms.Button btnFTP;
    }
}
