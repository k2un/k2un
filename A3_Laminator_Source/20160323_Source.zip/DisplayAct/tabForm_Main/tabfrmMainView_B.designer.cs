﻿namespace DisplayAct
{
    partial class tabfrmMainView_B
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(tabfrmMainView_B));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv_UnitState = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pbGL01 = new System.Windows.Forms.PictureBox();
            this.pbFO03 = new System.Windows.Forms.PictureBox();
            this.pbFO04 = new System.Windows.Forms.PictureBox();
            this.pbAL01 = new System.Windows.Forms.PictureBox();
            this.pbFT01 = new System.Windows.Forms.PictureBox();
            this.pbFI02 = new System.Windows.Forms.PictureBox();
            this.pbFI01 = new System.Windows.Forms.PictureBox();
            this.pbFT02 = new System.Windows.Forms.PictureBox();
            this.pbST02 = new System.Windows.Forms.PictureBox();
            this.pbPI01 = new System.Windows.Forms.PictureBox();
            this.pbST01 = new System.Windows.Forms.PictureBox();
            this.pbIS01 = new System.Windows.Forms.PictureBox();
            this.pbLM01 = new System.Windows.Forms.PictureBox();
            this.pbDM01 = new System.Windows.Forms.PictureBox();
            this.pbPO02 = new System.Windows.Forms.PictureBox();
            this.pbMain = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UnitState)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbGL01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFO03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFO04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAL01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFT01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFI02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFI01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFT02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbST02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPI01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbST01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIS01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLM01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDM01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPO02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 900F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 428F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(930, 578);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(18, 431);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(894, 144);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv_UnitState);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(886, 118);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "UNIT";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgv_UnitState
            // 
            this.dgv_UnitState.AllowUserToAddRows = false;
            this.dgv_UnitState.AllowUserToDeleteRows = false;
            this.dgv_UnitState.AllowUserToResizeColumns = false;
            this.dgv_UnitState.AllowUserToResizeRows = false;
            this.dgv_UnitState.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_UnitState.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_UnitState.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_UnitState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("맑은 고딕", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_UnitState.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_UnitState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_UnitState.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_UnitState.GridColor = System.Drawing.SystemColors.Control;
            this.dgv_UnitState.Location = new System.Drawing.Point(3, 3);
            this.dgv_UnitState.MultiSelect = false;
            this.dgv_UnitState.Name = "dgv_UnitState";
            this.dgv_UnitState.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_UnitState.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_UnitState.RowHeadersWidth = 130;
            this.dgv_UnitState.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Transparent;
            this.dgv_UnitState.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_UnitState.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgv_UnitState.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.dgv_UnitState.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Transparent;
            this.dgv_UnitState.RowTemplate.Height = 45;
            this.dgv_UnitState.RowTemplate.ReadOnly = true;
            this.dgv_UnitState.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgv_UnitState.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_UnitState.ShowCellErrors = false;
            this.dgv_UnitState.ShowCellToolTips = false;
            this.dgv_UnitState.ShowEditingIcon = false;
            this.dgv_UnitState.ShowRowErrors = false;
            this.dgv_UnitState.Size = new System.Drawing.Size(880, 112);
            this.dgv_UnitState.TabIndex = 0;
            this.dgv_UnitState.VisibleChanged += new System.EventHandler(this.dgv_UnitState_VisibleChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pbGL01);
            this.panel1.Controls.Add(this.pbFO03);
            this.panel1.Controls.Add(this.pbFO04);
            this.panel1.Controls.Add(this.pbAL01);
            this.panel1.Controls.Add(this.pbFT01);
            this.panel1.Controls.Add(this.pbFI02);
            this.panel1.Controls.Add(this.pbFI01);
            this.panel1.Controls.Add(this.pbFT02);
            this.panel1.Controls.Add(this.pbST02);
            this.panel1.Controls.Add(this.pbPI01);
            this.panel1.Controls.Add(this.pbST01);
            this.panel1.Controls.Add(this.pbIS01);
            this.panel1.Controls.Add(this.pbLM01);
            this.panel1.Controls.Add(this.pbDM01);
            this.panel1.Controls.Add(this.pbPO02);
            this.panel1.Controls.Add(this.pbMain);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(18, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(894, 422);
            this.panel1.TabIndex = 0;
            // 
            // pbGL01
            // 
            this.pbGL01.BackColor = System.Drawing.Color.Transparent;
            this.pbGL01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbGL01.BackgroundImage")));
            this.pbGL01.Location = new System.Drawing.Point(764, 24);
            this.pbGL01.Name = "pbGL01";
            this.pbGL01.Size = new System.Drawing.Size(95, 35);
            this.pbGL01.TabIndex = 16;
            this.pbGL01.TabStop = false;
            this.pbGL01.Visible = false;
            // 
            // pbFO03
            // 
            this.pbFO03.BackColor = System.Drawing.Color.Transparent;
            this.pbFO03.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFO03.BackgroundImage")));
            this.pbFO03.Location = new System.Drawing.Point(150, 338);
            this.pbFO03.Name = "pbFO03";
            this.pbFO03.Size = new System.Drawing.Size(94, 35);
            this.pbFO03.TabIndex = 15;
            this.pbFO03.TabStop = false;
            this.pbFO03.Visible = false;
            // 
            // pbFO04
            // 
            this.pbFO04.BackColor = System.Drawing.Color.Transparent;
            this.pbFO04.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFO04.BackgroundImage")));
            this.pbFO04.Location = new System.Drawing.Point(34, 338);
            this.pbFO04.Name = "pbFO04";
            this.pbFO04.Size = new System.Drawing.Size(94, 35);
            this.pbFO04.TabIndex = 14;
            this.pbFO04.TabStop = false;
            this.pbFO04.Visible = false;
            // 
            // pbAL01
            // 
            this.pbAL01.BackColor = System.Drawing.Color.Transparent;
            this.pbAL01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbAL01.BackgroundImage")));
            this.pbAL01.Location = new System.Drawing.Point(409, 263);
            this.pbAL01.Name = "pbAL01";
            this.pbAL01.Size = new System.Drawing.Size(94, 35);
            this.pbAL01.TabIndex = 13;
            this.pbAL01.TabStop = false;
            this.pbAL01.Visible = false;
            // 
            // pbFT01
            // 
            this.pbFT01.BackColor = System.Drawing.Color.Transparent;
            this.pbFT01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFT01.BackgroundImage")));
            this.pbFT01.Location = new System.Drawing.Point(296, 263);
            this.pbFT01.Name = "pbFT01";
            this.pbFT01.Size = new System.Drawing.Size(94, 35);
            this.pbFT01.TabIndex = 12;
            this.pbFT01.TabStop = false;
            this.pbFT01.Visible = false;
            // 
            // pbFI02
            // 
            this.pbFI02.BackColor = System.Drawing.Color.Transparent;
            this.pbFI02.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFI02.BackgroundImage")));
            this.pbFI02.Location = new System.Drawing.Point(187, 263);
            this.pbFI02.Name = "pbFI02";
            this.pbFI02.Size = new System.Drawing.Size(94, 35);
            this.pbFI02.TabIndex = 11;
            this.pbFI02.TabStop = false;
            this.pbFI02.Visible = false;
            // 
            // pbFI01
            // 
            this.pbFI01.BackColor = System.Drawing.Color.Transparent;
            this.pbFI01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFI01.BackgroundImage")));
            this.pbFI01.Location = new System.Drawing.Point(76, 263);
            this.pbFI01.Name = "pbFI01";
            this.pbFI01.Size = new System.Drawing.Size(94, 35);
            this.pbFI01.TabIndex = 10;
            this.pbFI01.TabStop = false;
            this.pbFI01.Visible = false;
            // 
            // pbFT02
            // 
            this.pbFT02.BackColor = System.Drawing.Color.Transparent;
            this.pbFT02.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbFT02.BackgroundImage")));
            this.pbFT02.Location = new System.Drawing.Point(455, 178);
            this.pbFT02.Name = "pbFT02";
            this.pbFT02.Size = new System.Drawing.Size(94, 35);
            this.pbFT02.TabIndex = 9;
            this.pbFT02.TabStop = false;
            this.pbFT02.Visible = false;
            // 
            // pbST02
            // 
            this.pbST02.BackColor = System.Drawing.Color.Transparent;
            this.pbST02.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbST02.BackgroundImage")));
            this.pbST02.Location = new System.Drawing.Point(706, 165);
            this.pbST02.Name = "pbST02";
            this.pbST02.Size = new System.Drawing.Size(94, 35);
            this.pbST02.TabIndex = 8;
            this.pbST02.TabStop = false;
            this.pbST02.Visible = false;
            // 
            // pbPI01
            // 
            this.pbPI01.BackColor = System.Drawing.Color.Transparent;
            this.pbPI01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPI01.BackgroundImage")));
            this.pbPI01.Location = new System.Drawing.Point(255, 167);
            this.pbPI01.Name = "pbPI01";
            this.pbPI01.Size = new System.Drawing.Size(94, 35);
            this.pbPI01.TabIndex = 7;
            this.pbPI01.TabStop = false;
            this.pbPI01.Visible = false;
            // 
            // pbST01
            // 
            this.pbST01.BackColor = System.Drawing.Color.Transparent;
            this.pbST01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbST01.BackgroundImage")));
            this.pbST01.Location = new System.Drawing.Point(735, 90);
            this.pbST01.Name = "pbST01";
            this.pbST01.Size = new System.Drawing.Size(95, 35);
            this.pbST01.TabIndex = 6;
            this.pbST01.TabStop = false;
            this.pbST01.Visible = false;
            // 
            // pbIS01
            // 
            this.pbIS01.BackColor = System.Drawing.Color.Transparent;
            this.pbIS01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbIS01.BackgroundImage")));
            this.pbIS01.Location = new System.Drawing.Point(626, 90);
            this.pbIS01.Name = "pbIS01";
            this.pbIS01.Size = new System.Drawing.Size(93, 35);
            this.pbIS01.TabIndex = 5;
            this.pbIS01.TabStop = false;
            this.pbIS01.Visible = false;
            // 
            // pbLM01
            // 
            this.pbLM01.BackColor = System.Drawing.Color.Transparent;
            this.pbLM01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbLM01.BackgroundImage")));
            this.pbLM01.Location = new System.Drawing.Point(506, 90);
            this.pbLM01.Name = "pbLM01";
            this.pbLM01.Size = new System.Drawing.Size(95, 35);
            this.pbLM01.TabIndex = 4;
            this.pbLM01.TabStop = false;
            this.pbLM01.Visible = false;
            // 
            // pbDM01
            // 
            this.pbDM01.BackColor = System.Drawing.Color.Transparent;
            this.pbDM01.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbDM01.BackgroundImage")));
            this.pbDM01.Location = new System.Drawing.Point(394, 90);
            this.pbDM01.Name = "pbDM01";
            this.pbDM01.Size = new System.Drawing.Size(94, 35);
            this.pbDM01.TabIndex = 3;
            this.pbDM01.TabStop = false;
            this.pbDM01.Visible = false;
            // 
            // pbPO02
            // 
            this.pbPO02.BackColor = System.Drawing.Color.Transparent;
            this.pbPO02.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPO02.BackgroundImage")));
            this.pbPO02.Location = new System.Drawing.Point(285, 90);
            this.pbPO02.Name = "pbPO02";
            this.pbPO02.Size = new System.Drawing.Size(92, 35);
            this.pbPO02.TabIndex = 2;
            this.pbPO02.TabStop = false;
            this.pbPO02.Visible = false;
            // 
            // pbMain
            // 
            this.pbMain.BackColor = System.Drawing.Color.Transparent;
            this.pbMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbMain.BackgroundImage")));
            this.pbMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbMain.Location = new System.Drawing.Point(0, 0);
            this.pbMain.Name = "pbMain";
            this.pbMain.Size = new System.Drawing.Size(894, 422);
            this.pbMain.TabIndex = 1;
            this.pbMain.TabStop = false;
            // 
            // tabfrmMainView_B
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "tabfrmMainView_B";
            this.Size = new System.Drawing.Size(930, 578);
            this.Tag = "Main View";
            this.Load += new System.EventHandler(this.tabfrmMainView_1024_Load);
            this.VisibleChanged += new System.EventHandler(this.tabfrmMainView_T_VisibleChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabfrmMainView_1024_KeyDown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UnitState)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbGL01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFO03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFO04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAL01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFT01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFI02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFI01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFT02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbST02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPI01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbST01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIS01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLM01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDM01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPO02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbPO02;
        private System.Windows.Forms.PictureBox pbMain;
        private System.Windows.Forms.PictureBox pbST01;
        private System.Windows.Forms.PictureBox pbIS01;
        private System.Windows.Forms.PictureBox pbLM01;
        private System.Windows.Forms.PictureBox pbDM01;
        private System.Windows.Forms.PictureBox pbFT02;
        private System.Windows.Forms.PictureBox pbST02;
        private System.Windows.Forms.PictureBox pbPI01;
        private System.Windows.Forms.PictureBox pbFO03;
        private System.Windows.Forms.PictureBox pbFO04;
        private System.Windows.Forms.PictureBox pbAL01;
        private System.Windows.Forms.PictureBox pbFT01;
        private System.Windows.Forms.PictureBox pbFI02;
        private System.Windows.Forms.PictureBox pbFI01;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgv_UnitState;
        private System.Windows.Forms.PictureBox pbGL01;

    }
}
