﻿namespace DisplayAct
{
    partial class frmSimulationTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnClose = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.page1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtFilmScrap_UnitID = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnFilmUnScrap = new System.Windows.Forms.Button();
            this.txtFilmScrap_SlotID = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtFilmScrap_LOTID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.btnFilmScrap = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.btnProcessDataCheck = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtST01_LotEnd = new System.Windows.Forms.TextBox();
            this.txtST01_LOTStart = new System.Windows.Forms.TextBox();
            this.txtST01_SlotID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtST01_HostPPID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtST01_GLSID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnST01_O = new System.Windows.Forms.Button();
            this.txtST01_LOTID = new System.Windows.Forms.TextBox();
            this.btnST01_I = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.txtFilmCount = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnIS01_O = new System.Windows.Forms.Button();
            this.btnIS01_In = new System.Windows.Forms.Button();
            this.btnDM01_O = new System.Windows.Forms.Button();
            this.btnDM01_In = new System.Windows.Forms.Button();
            this.btnLM01_O = new System.Windows.Forms.Button();
            this.btnLM01_In = new System.Windows.Forms.Button();
            this.btnFT02_O = new System.Windows.Forms.Button();
            this.btnFT02_In = new System.Windows.Forms.Button();
            this.btnAL01_O = new System.Windows.Forms.Button();
            this.btnAL01_In = new System.Windows.Forms.Button();
            this.btnFT01_O = new System.Windows.Forms.Button();
            this.btnFT01_In = new System.Windows.Forms.Button();
            this.btnFI02_Out = new System.Windows.Forms.Button();
            this.btnFI02_In = new System.Windows.Forms.Button();
            this.btnFI01_Out = new System.Windows.Forms.Button();
            this.txtSlotID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLOTID = new System.Windows.Forms.TextBox();
            this.btnFI01_In = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtGlassScrap_UnitID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGLSUnScrap = new System.Windows.Forms.Button();
            this.txtGlassScrap_SlotID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtGlassScrap_LOTID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnGLSScrap = new System.Windows.Forms.Button();
            this.tabAlarm = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btnAlarmReset = new System.Windows.Forms.Button();
            this.txtAlarmID = new System.Windows.Forms.TextBox();
            this.btnAlarmSet = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtOven_APD10 = new System.Windows.Forms.TextBox();
            this.txtOven_APD09 = new System.Windows.Forms.TextBox();
            this.txtOven_APD08 = new System.Windows.Forms.TextBox();
            this.txtOven_APD07 = new System.Windows.Forms.TextBox();
            this.txtOven_APD06 = new System.Windows.Forms.TextBox();
            this.txtOven_APD05 = new System.Windows.Forms.TextBox();
            this.txtOven_APD04 = new System.Windows.Forms.TextBox();
            this.txtOven_APD03 = new System.Windows.Forms.TextBox();
            this.txtOven_APD02 = new System.Windows.Forms.TextBox();
            this.txtOven_APD01 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCLN_APD10 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD09 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD08 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD07 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD06 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD05 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD04 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD03 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD02 = new System.Windows.Forms.TextBox();
            this.txtCLN_APD01 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button15 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.txtEqpPPID2 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.txtEqpPPID = new System.Windows.Forms.TextBox();
            this.txthostppid = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtEQPPPIDMap03 = new System.Windows.Forms.TextBox();
            this.txtEQPPPIDMap02 = new System.Windows.Forms.TextBox();
            this.btnEQPPPID_ListUpdate = new System.Windows.Forms.Button();
            this.txtEQPPPIDMap01 = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tmrUpdate = new System.Windows.Forms.Timer(this.components);
            this.button25 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.page1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabAlarm.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel1.Controls.Add(this.btnClose, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tabControl, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1172, 572);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnClose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnClose.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnClose.Location = new System.Drawing.Point(1025, 525);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(144, 44);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // tabControl
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tabControl, 2);
            this.tabControl.Controls.Add(this.page1);
            this.tabControl.Controls.Add(this.tabAlarm);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1172, 522);
            this.tabControl.TabIndex = 2;
            // 
            // page1
            // 
            this.page1.Controls.Add(this.groupBox7);
            this.page1.Controls.Add(this.groupBox6);
            this.page1.Controls.Add(this.groupBox4);
            this.page1.Controls.Add(this.groupBox5);
            this.page1.Location = new System.Drawing.Point(4, 22);
            this.page1.Margin = new System.Windows.Forms.Padding(0);
            this.page1.Name = "page1";
            this.page1.Padding = new System.Windows.Forms.Padding(3);
            this.page1.Size = new System.Drawing.Size(1164, 496);
            this.page1.TabIndex = 2;
            this.page1.Text = "GlassScenario";
            this.page1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtFilmScrap_UnitID);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.btnFilmUnScrap);
            this.groupBox7.Controls.Add(this.txtFilmScrap_SlotID);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.txtFilmScrap_LOTID);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.btnFilmScrap);
            this.groupBox7.Location = new System.Drawing.Point(3, 347);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(410, 120);
            this.groupBox7.TabIndex = 11;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Film Scrap";
            // 
            // txtFilmScrap_UnitID
            // 
            this.txtFilmScrap_UnitID.Location = new System.Drawing.Point(81, 70);
            this.txtFilmScrap_UnitID.Name = "txtFilmScrap_UnitID";
            this.txtFilmScrap_UnitID.Size = new System.Drawing.Size(157, 21);
            this.txtFilmScrap_UnitID.TabIndex = 14;
            this.txtFilmScrap_UnitID.Text = "3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(26, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 12);
            this.label11.TabIndex = 13;
            this.label11.Text = "UnitID";
            // 
            // btnFilmUnScrap
            // 
            this.btnFilmUnScrap.BackColor = System.Drawing.Color.LightGray;
            this.btnFilmUnScrap.Font = new System.Drawing.Font("휴먼둥근헤드라인", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFilmUnScrap.Location = new System.Drawing.Point(253, 64);
            this.btnFilmUnScrap.Name = "btnFilmUnScrap";
            this.btnFilmUnScrap.Size = new System.Drawing.Size(151, 44);
            this.btnFilmUnScrap.TabIndex = 10;
            this.btnFilmUnScrap.Text = "UnScrap";
            this.btnFilmUnScrap.UseVisualStyleBackColor = false;
            this.btnFilmUnScrap.Click += new System.EventHandler(this.btnFilmUnScrap_Click);
            // 
            // txtFilmScrap_SlotID
            // 
            this.txtFilmScrap_SlotID.Location = new System.Drawing.Point(81, 43);
            this.txtFilmScrap_SlotID.Name = "txtFilmScrap_SlotID";
            this.txtFilmScrap_SlotID.Size = new System.Drawing.Size(157, 21);
            this.txtFilmScrap_SlotID.TabIndex = 5;
            this.txtFilmScrap_SlotID.Text = "1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(26, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 12);
            this.label14.TabIndex = 4;
            this.label14.Text = "SlotID";
            // 
            // txtFilmScrap_LOTID
            // 
            this.txtFilmScrap_LOTID.Location = new System.Drawing.Point(81, 16);
            this.txtFilmScrap_LOTID.Name = "txtFilmScrap_LOTID";
            this.txtFilmScrap_LOTID.Size = new System.Drawing.Size(157, 21);
            this.txtFilmScrap_LOTID.TabIndex = 3;
            this.txtFilmScrap_LOTID.Text = "LOTID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(21, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "LOTID";
            // 
            // btnFilmScrap
            // 
            this.btnFilmScrap.BackColor = System.Drawing.Color.LightGray;
            this.btnFilmScrap.Font = new System.Drawing.Font("휴먼둥근헤드라인", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFilmScrap.Location = new System.Drawing.Point(254, 14);
            this.btnFilmScrap.Name = "btnFilmScrap";
            this.btnFilmScrap.Size = new System.Drawing.Size(151, 44);
            this.btnFilmScrap.TabIndex = 0;
            this.btnFilmScrap.Text = "Scrap";
            this.btnFilmScrap.UseVisualStyleBackColor = false;
            this.btnFilmScrap.Click += new System.EventHandler(this.btnFilmScrap_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button24);
            this.groupBox6.Controls.Add(this.button23);
            this.groupBox6.Controls.Add(this.btnProcessDataCheck);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.txtST01_LotEnd);
            this.groupBox6.Controls.Add(this.txtST01_LOTStart);
            this.groupBox6.Controls.Add(this.txtST01_SlotID);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.txtST01_HostPPID);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.txtST01_GLSID);
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Controls.Add(this.btnST01_O);
            this.groupBox6.Controls.Add(this.txtST01_LOTID);
            this.groupBox6.Controls.Add(this.btnST01_I);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Location = new System.Drawing.Point(8, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(410, 200);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "ST01";
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.LightGray;
            this.button24.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button24.Location = new System.Drawing.Point(330, 122);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(70, 48);
            this.button24.TabIndex = 16;
            this.button24.Text = "배출보고";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.LightGray;
            this.button23.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button23.Location = new System.Drawing.Point(254, 122);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(70, 48);
            this.button23.TabIndex = 15;
            this.button23.Text = "도착 보고";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // btnProcessDataCheck
            // 
            this.btnProcessDataCheck.BackColor = System.Drawing.Color.LightGray;
            this.btnProcessDataCheck.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnProcessDataCheck.Location = new System.Drawing.Point(253, 12);
            this.btnProcessDataCheck.Name = "btnProcessDataCheck";
            this.btnProcessDataCheck.Size = new System.Drawing.Size(151, 48);
            this.btnProcessDataCheck.TabIndex = 14;
            this.btnProcessDataCheck.Text = "Check";
            this.btnProcessDataCheck.UseVisualStyleBackColor = false;
            this.btnProcessDataCheck.Click += new System.EventHandler(this.btnProcessDataCheck_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 164);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 12);
            this.label12.TabIndex = 13;
            this.label12.Text = "LotEnd";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 12);
            this.label10.TabIndex = 12;
            this.label10.Text = "LotStart";
            // 
            // txtST01_LotEnd
            // 
            this.txtST01_LotEnd.Location = new System.Drawing.Point(90, 164);
            this.txtST01_LotEnd.Name = "txtST01_LotEnd";
            this.txtST01_LotEnd.Size = new System.Drawing.Size(151, 21);
            this.txtST01_LotEnd.TabIndex = 11;
            this.txtST01_LotEnd.Text = "1";
            // 
            // txtST01_LOTStart
            // 
            this.txtST01_LOTStart.Location = new System.Drawing.Point(90, 137);
            this.txtST01_LOTStart.Name = "txtST01_LOTStart";
            this.txtST01_LOTStart.Size = new System.Drawing.Size(151, 21);
            this.txtST01_LOTStart.TabIndex = 10;
            this.txtST01_LOTStart.Text = "1";
            // 
            // txtST01_SlotID
            // 
            this.txtST01_SlotID.Location = new System.Drawing.Point(92, 71);
            this.txtST01_SlotID.Name = "txtST01_SlotID";
            this.txtST01_SlotID.Size = new System.Drawing.Size(151, 21);
            this.txtST01_SlotID.TabIndex = 9;
            this.txtST01_SlotID.Text = "1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "SlotID";
            // 
            // txtST01_HostPPID
            // 
            this.txtST01_HostPPID.Location = new System.Drawing.Point(92, 98);
            this.txtST01_HostPPID.Name = "txtST01_HostPPID";
            this.txtST01_HostPPID.Size = new System.Drawing.Size(151, 21);
            this.txtST01_HostPPID.TabIndex = 7;
            this.txtST01_HostPPID.Text = "H1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "HostPPID";
            // 
            // txtST01_GLSID
            // 
            this.txtST01_GLSID.Location = new System.Drawing.Point(92, 45);
            this.txtST01_GLSID.Name = "txtST01_GLSID";
            this.txtST01_GLSID.Size = new System.Drawing.Size(151, 21);
            this.txtST01_GLSID.TabIndex = 5;
            this.txtST01_GLSID.Text = "GLASSA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "GLSID";
            // 
            // btnST01_O
            // 
            this.btnST01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnST01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnST01_O.Location = new System.Drawing.Point(329, 68);
            this.btnST01_O.Name = "btnST01_O";
            this.btnST01_O.Size = new System.Drawing.Size(70, 48);
            this.btnST01_O.TabIndex = 2;
            this.btnST01_O.Text = "배출 보고";
            this.btnST01_O.UseVisualStyleBackColor = false;
            this.btnST01_O.Click += new System.EventHandler(this.btnST01_O_Click);
            // 
            // txtST01_LOTID
            // 
            this.txtST01_LOTID.Location = new System.Drawing.Point(92, 18);
            this.txtST01_LOTID.Name = "txtST01_LOTID";
            this.txtST01_LOTID.Size = new System.Drawing.Size(151, 21);
            this.txtST01_LOTID.TabIndex = 3;
            this.txtST01_LOTID.Text = "LOTID";
            // 
            // btnST01_I
            // 
            this.btnST01_I.BackColor = System.Drawing.Color.LightGray;
            this.btnST01_I.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnST01_I.Location = new System.Drawing.Point(253, 68);
            this.btnST01_I.Name = "btnST01_I";
            this.btnST01_I.Size = new System.Drawing.Size(70, 48);
            this.btnST01_I.TabIndex = 1;
            this.btnST01_I.Text = "도착 보고";
            this.btnST01_I.UseVisualStyleBackColor = false;
            this.btnST01_I.Click += new System.EventHandler(this.btnST01_I_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "LOTID";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.button25);
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.button17);
            this.groupBox4.Controls.Add(this.button18);
            this.groupBox4.Controls.Add(this.button19);
            this.groupBox4.Controls.Add(this.button22);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.txtFilmCount);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.btnIS01_O);
            this.groupBox4.Controls.Add(this.btnIS01_In);
            this.groupBox4.Controls.Add(this.btnDM01_O);
            this.groupBox4.Controls.Add(this.btnDM01_In);
            this.groupBox4.Controls.Add(this.btnLM01_O);
            this.groupBox4.Controls.Add(this.btnLM01_In);
            this.groupBox4.Controls.Add(this.btnFT02_O);
            this.groupBox4.Controls.Add(this.btnFT02_In);
            this.groupBox4.Controls.Add(this.btnAL01_O);
            this.groupBox4.Controls.Add(this.btnAL01_In);
            this.groupBox4.Controls.Add(this.btnFT01_O);
            this.groupBox4.Controls.Add(this.btnFT01_In);
            this.groupBox4.Controls.Add(this.btnFI02_Out);
            this.groupBox4.Controls.Add(this.btnFI02_In);
            this.groupBox4.Controls.Add(this.btnFI01_Out);
            this.groupBox4.Controls.Add(this.txtSlotID);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txtLOTID);
            this.groupBox4.Controls.Add(this.btnFI01_In);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(424, 8);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(670, 448);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Film 구간";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(92, 280);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(151, 21);
            this.textBox5.TabIndex = 36;
            this.textBox5.Text = "PAGECASE";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 283);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(86, 12);
            this.label19.TabIndex = 35;
            this.label19.Text = "이형지 CaseID";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.LightGray;
            this.button17.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button17.Location = new System.Drawing.Point(135, 390);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(105, 45);
            this.button17.TabIndex = 34;
            this.button17.Text = "PO02_O";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.LightGray;
            this.button18.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button18.Location = new System.Drawing.Point(24, 390);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(105, 45);
            this.button18.TabIndex = 33;
            this.button18.Text = "PO02_I";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.LightGray;
            this.button19.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button19.Location = new System.Drawing.Point(135, 339);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(105, 45);
            this.button19.TabIndex = 32;
            this.button19.Text = "PI01_O";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.LightGray;
            this.button22.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button22.Location = new System.Drawing.Point(24, 339);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(105, 45);
            this.button22.TabIndex = 31;
            this.button22.Text = "PI01_I";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(92, 159);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(151, 21);
            this.textBox3.TabIndex = 30;
            this.textBox3.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 160);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 12);
            this.label17.TabIndex = 29;
            this.label17.Text = "SlotID";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(92, 132);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(151, 21);
            this.textBox4.TabIndex = 28;
            this.textBox4.Text = "FILMID";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(22, 135);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 12);
            this.label18.TabIndex = 27;
            this.label18.Text = "FilmID";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(564, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 45);
            this.button1.TabIndex = 26;
            this.button1.Text = "FO04_O";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(461, 61);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 45);
            this.button2.TabIndex = 25;
            this.button2.Text = "FO04_I";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightGray;
            this.button3.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(355, 62);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 45);
            this.button3.TabIndex = 24;
            this.button3.Text = "FO03_O";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LightGray;
            this.button4.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button4.Location = new System.Drawing.Point(249, 62);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 45);
            this.button4.TabIndex = 23;
            this.button4.Text = "FO03_I";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtFilmCount
            // 
            this.txtFilmCount.Location = new System.Drawing.Point(92, 45);
            this.txtFilmCount.Name = "txtFilmCount";
            this.txtFilmCount.Size = new System.Drawing.Size(151, 21);
            this.txtFilmCount.TabIndex = 22;
            this.txtFilmCount.Text = "25";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 46);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "FilmCount";
            // 
            // btnIS01_O
            // 
            this.btnIS01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnIS01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnIS01_O.Location = new System.Drawing.Point(375, 382);
            this.btnIS01_O.Name = "btnIS01_O";
            this.btnIS01_O.Size = new System.Drawing.Size(120, 45);
            this.btnIS01_O.TabIndex = 20;
            this.btnIS01_O.Text = "IS01_O";
            this.btnIS01_O.UseVisualStyleBackColor = false;
            this.btnIS01_O.Click += new System.EventHandler(this.btnIS01_O_Click);
            // 
            // btnIS01_In
            // 
            this.btnIS01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnIS01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnIS01_In.Location = new System.Drawing.Point(249, 382);
            this.btnIS01_In.Name = "btnIS01_In";
            this.btnIS01_In.Size = new System.Drawing.Size(120, 45);
            this.btnIS01_In.TabIndex = 19;
            this.btnIS01_In.Text = "IS01_I";
            this.btnIS01_In.UseVisualStyleBackColor = false;
            this.btnIS01_In.Click += new System.EventHandler(this.btnIS01_In_Click);
            // 
            // btnDM01_O
            // 
            this.btnDM01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnDM01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnDM01_O.Location = new System.Drawing.Point(375, 331);
            this.btnDM01_O.Name = "btnDM01_O";
            this.btnDM01_O.Size = new System.Drawing.Size(120, 45);
            this.btnDM01_O.TabIndex = 18;
            this.btnDM01_O.Text = "DM01_O";
            this.btnDM01_O.UseVisualStyleBackColor = false;
            this.btnDM01_O.Click += new System.EventHandler(this.btnDM01_O_Click);
            // 
            // btnDM01_In
            // 
            this.btnDM01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnDM01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnDM01_In.Location = new System.Drawing.Point(249, 331);
            this.btnDM01_In.Name = "btnDM01_In";
            this.btnDM01_In.Size = new System.Drawing.Size(120, 45);
            this.btnDM01_In.TabIndex = 17;
            this.btnDM01_In.Text = "DM01_I";
            this.btnDM01_In.UseVisualStyleBackColor = false;
            this.btnDM01_In.Click += new System.EventHandler(this.btnDM01_In_Click);
            // 
            // btnLM01_O
            // 
            this.btnLM01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnLM01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLM01_O.Location = new System.Drawing.Point(375, 280);
            this.btnLM01_O.Name = "btnLM01_O";
            this.btnLM01_O.Size = new System.Drawing.Size(120, 45);
            this.btnLM01_O.TabIndex = 16;
            this.btnLM01_O.Text = "LM01_O";
            this.btnLM01_O.UseVisualStyleBackColor = false;
            this.btnLM01_O.Click += new System.EventHandler(this.btnLM01_O_Click);
            // 
            // btnLM01_In
            // 
            this.btnLM01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnLM01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLM01_In.Location = new System.Drawing.Point(249, 280);
            this.btnLM01_In.Name = "btnLM01_In";
            this.btnLM01_In.Size = new System.Drawing.Size(120, 45);
            this.btnLM01_In.TabIndex = 15;
            this.btnLM01_In.Text = "LM01_I";
            this.btnLM01_In.UseVisualStyleBackColor = false;
            this.btnLM01_In.Click += new System.EventHandler(this.btnLM01_In_Click);
            // 
            // btnFT02_O
            // 
            this.btnFT02_O.BackColor = System.Drawing.Color.LightGray;
            this.btnFT02_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFT02_O.Location = new System.Drawing.Point(375, 229);
            this.btnFT02_O.Name = "btnFT02_O";
            this.btnFT02_O.Size = new System.Drawing.Size(120, 45);
            this.btnFT02_O.TabIndex = 14;
            this.btnFT02_O.Text = "FT02_O";
            this.btnFT02_O.UseVisualStyleBackColor = false;
            this.btnFT02_O.Click += new System.EventHandler(this.btnFT02_O_Click);
            // 
            // btnFT02_In
            // 
            this.btnFT02_In.BackColor = System.Drawing.Color.LightGray;
            this.btnFT02_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFT02_In.Location = new System.Drawing.Point(249, 229);
            this.btnFT02_In.Name = "btnFT02_In";
            this.btnFT02_In.Size = new System.Drawing.Size(120, 45);
            this.btnFT02_In.TabIndex = 13;
            this.btnFT02_In.Text = "FT02_I";
            this.btnFT02_In.UseVisualStyleBackColor = false;
            this.btnFT02_In.Click += new System.EventHandler(this.btnFT02_In_Click);
            // 
            // btnAL01_O
            // 
            this.btnAL01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnAL01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnAL01_O.Location = new System.Drawing.Point(375, 178);
            this.btnAL01_O.Name = "btnAL01_O";
            this.btnAL01_O.Size = new System.Drawing.Size(120, 45);
            this.btnAL01_O.TabIndex = 12;
            this.btnAL01_O.Text = "AL01_O";
            this.btnAL01_O.UseVisualStyleBackColor = false;
            this.btnAL01_O.Click += new System.EventHandler(this.btnAL01_O_Click);
            // 
            // btnAL01_In
            // 
            this.btnAL01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnAL01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnAL01_In.Location = new System.Drawing.Point(249, 178);
            this.btnAL01_In.Name = "btnAL01_In";
            this.btnAL01_In.Size = new System.Drawing.Size(120, 45);
            this.btnAL01_In.TabIndex = 11;
            this.btnAL01_In.Text = "AL01_I";
            this.btnAL01_In.UseVisualStyleBackColor = false;
            this.btnAL01_In.Click += new System.EventHandler(this.btnAL01_In_Click);
            // 
            // btnFT01_O
            // 
            this.btnFT01_O.BackColor = System.Drawing.Color.LightGray;
            this.btnFT01_O.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFT01_O.Location = new System.Drawing.Point(375, 127);
            this.btnFT01_O.Name = "btnFT01_O";
            this.btnFT01_O.Size = new System.Drawing.Size(120, 45);
            this.btnFT01_O.TabIndex = 10;
            this.btnFT01_O.Text = "FT01_O";
            this.btnFT01_O.UseVisualStyleBackColor = false;
            this.btnFT01_O.Click += new System.EventHandler(this.btnFT01_O_Click);
            // 
            // btnFT01_In
            // 
            this.btnFT01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnFT01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFT01_In.Location = new System.Drawing.Point(249, 127);
            this.btnFT01_In.Name = "btnFT01_In";
            this.btnFT01_In.Size = new System.Drawing.Size(120, 45);
            this.btnFT01_In.TabIndex = 9;
            this.btnFT01_In.Text = "FT01_I";
            this.btnFT01_In.UseVisualStyleBackColor = false;
            this.btnFT01_In.Click += new System.EventHandler(this.btnFT01_In_Click);
            // 
            // btnFI02_Out
            // 
            this.btnFI02_Out.BackColor = System.Drawing.Color.LightGray;
            this.btnFI02_Out.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFI02_Out.Location = new System.Drawing.Point(564, 10);
            this.btnFI02_Out.Name = "btnFI02_Out";
            this.btnFI02_Out.Size = new System.Drawing.Size(100, 45);
            this.btnFI02_Out.TabIndex = 8;
            this.btnFI02_Out.Text = "FI02_O";
            this.btnFI02_Out.UseVisualStyleBackColor = false;
            this.btnFI02_Out.Click += new System.EventHandler(this.btnFI02_Out_Click);
            // 
            // btnFI02_In
            // 
            this.btnFI02_In.BackColor = System.Drawing.Color.LightGray;
            this.btnFI02_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFI02_In.Location = new System.Drawing.Point(461, 10);
            this.btnFI02_In.Name = "btnFI02_In";
            this.btnFI02_In.Size = new System.Drawing.Size(100, 45);
            this.btnFI02_In.TabIndex = 7;
            this.btnFI02_In.Text = "FI02_I";
            this.btnFI02_In.UseVisualStyleBackColor = false;
            this.btnFI02_In.Click += new System.EventHandler(this.btnFI02_In_Click);
            // 
            // btnFI01_Out
            // 
            this.btnFI01_Out.BackColor = System.Drawing.Color.LightGray;
            this.btnFI01_Out.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFI01_Out.Location = new System.Drawing.Point(355, 11);
            this.btnFI01_Out.Name = "btnFI01_Out";
            this.btnFI01_Out.Size = new System.Drawing.Size(100, 45);
            this.btnFI01_Out.TabIndex = 6;
            this.btnFI01_Out.Text = "FI01_O";
            this.btnFI01_Out.UseVisualStyleBackColor = false;
            this.btnFI01_Out.Click += new System.EventHandler(this.btnFI01_Out_Click);
            // 
            // txtSlotID
            // 
            this.txtSlotID.Location = new System.Drawing.Point(92, 72);
            this.txtSlotID.Name = "txtSlotID";
            this.txtSlotID.Size = new System.Drawing.Size(151, 21);
            this.txtSlotID.TabIndex = 5;
            this.txtSlotID.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "SlotID";
            // 
            // txtLOTID
            // 
            this.txtLOTID.Location = new System.Drawing.Point(92, 18);
            this.txtLOTID.Name = "txtLOTID";
            this.txtLOTID.Size = new System.Drawing.Size(151, 21);
            this.txtLOTID.TabIndex = 3;
            this.txtLOTID.Text = "FILMID";
            // 
            // btnFI01_In
            // 
            this.btnFI01_In.BackColor = System.Drawing.Color.LightGray;
            this.btnFI01_In.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFI01_In.Location = new System.Drawing.Point(249, 12);
            this.btnFI01_In.Name = "btnFI01_In";
            this.btnFI01_In.Size = new System.Drawing.Size(100, 45);
            this.btnFI01_In.TabIndex = 1;
            this.btnFI01_In.Text = "FI01_I";
            this.btnFI01_In.UseVisualStyleBackColor = false;
            this.btnFI01_In.Click += new System.EventHandler(this.btnFI01_In_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "FilmID";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtGlassScrap_UnitID);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.btnGLSUnScrap);
            this.groupBox5.Controls.Add(this.txtGlassScrap_SlotID);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.txtGlassScrap_LOTID);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.btnGLSScrap);
            this.groupBox5.Location = new System.Drawing.Point(8, 212);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(410, 120);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Glass Scrap";
            // 
            // txtGlassScrap_UnitID
            // 
            this.txtGlassScrap_UnitID.Location = new System.Drawing.Point(81, 70);
            this.txtGlassScrap_UnitID.Name = "txtGlassScrap_UnitID";
            this.txtGlassScrap_UnitID.Size = new System.Drawing.Size(157, 21);
            this.txtGlassScrap_UnitID.TabIndex = 12;
            this.txtGlassScrap_UnitID.Text = "13";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "UnitID";
            // 
            // btnGLSUnScrap
            // 
            this.btnGLSUnScrap.BackColor = System.Drawing.Color.LightGray;
            this.btnGLSUnScrap.Font = new System.Drawing.Font("휴먼둥근헤드라인", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnGLSUnScrap.Location = new System.Drawing.Point(254, 70);
            this.btnGLSUnScrap.Name = "btnGLSUnScrap";
            this.btnGLSUnScrap.Size = new System.Drawing.Size(151, 44);
            this.btnGLSUnScrap.TabIndex = 10;
            this.btnGLSUnScrap.Text = "UnScrap";
            this.btnGLSUnScrap.UseVisualStyleBackColor = false;
            this.btnGLSUnScrap.Click += new System.EventHandler(this.btnGLSUnScrap_Click);
            // 
            // txtGlassScrap_SlotID
            // 
            this.txtGlassScrap_SlotID.Location = new System.Drawing.Point(81, 43);
            this.txtGlassScrap_SlotID.Name = "txtGlassScrap_SlotID";
            this.txtGlassScrap_SlotID.Size = new System.Drawing.Size(157, 21);
            this.txtGlassScrap_SlotID.TabIndex = 5;
            this.txtGlassScrap_SlotID.Text = "1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(26, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 12);
            this.label9.TabIndex = 4;
            this.label9.Text = "SlotID";
            // 
            // txtGlassScrap_LOTID
            // 
            this.txtGlassScrap_LOTID.Location = new System.Drawing.Point(81, 16);
            this.txtGlassScrap_LOTID.Name = "txtGlassScrap_LOTID";
            this.txtGlassScrap_LOTID.Size = new System.Drawing.Size(157, 21);
            this.txtGlassScrap_LOTID.TabIndex = 3;
            this.txtGlassScrap_LOTID.Text = "GlassID001";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "LOTID";
            // 
            // btnGLSScrap
            // 
            this.btnGLSScrap.BackColor = System.Drawing.Color.LightGray;
            this.btnGLSScrap.Font = new System.Drawing.Font("휴먼둥근헤드라인", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnGLSScrap.Location = new System.Drawing.Point(253, 20);
            this.btnGLSScrap.Name = "btnGLSScrap";
            this.btnGLSScrap.Size = new System.Drawing.Size(151, 44);
            this.btnGLSScrap.TabIndex = 0;
            this.btnGLSScrap.Text = "Scrap";
            this.btnGLSScrap.UseVisualStyleBackColor = false;
            this.btnGLSScrap.Click += new System.EventHandler(this.btnGLSScrap_Click);
            // 
            // tabAlarm
            // 
            this.tabAlarm.Controls.Add(this.button13);
            this.tabAlarm.Controls.Add(this.button16);
            this.tabAlarm.Controls.Add(this.button12);
            this.tabAlarm.Controls.Add(this.button11);
            this.tabAlarm.Controls.Add(this.btnAlarmReset);
            this.tabAlarm.Controls.Add(this.txtAlarmID);
            this.tabAlarm.Controls.Add(this.btnAlarmSet);
            this.tabAlarm.Location = new System.Drawing.Point(4, 22);
            this.tabAlarm.Name = "tabAlarm";
            this.tabAlarm.Padding = new System.Windows.Forms.Padding(3);
            this.tabAlarm.Size = new System.Drawing.Size(1164, 496);
            this.tabAlarm.TabIndex = 3;
            this.tabAlarm.Text = "Alarm";
            this.tabAlarm.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(257, 268);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(79, 37);
            this.button13.TabIndex = 12;
            this.button13.Text = "Resume";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(257, 206);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(79, 37);
            this.button16.TabIndex = 11;
            this.button16.Text = "PM";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(172, 268);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(79, 37);
            this.button12.TabIndex = 10;
            this.button12.Text = "Pause";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(172, 206);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(79, 37);
            this.button11.TabIndex = 9;
            this.button11.Text = "Normal";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnAlarmReset
            // 
            this.btnAlarmReset.Location = new System.Drawing.Point(172, 70);
            this.btnAlarmReset.Name = "btnAlarmReset";
            this.btnAlarmReset.Size = new System.Drawing.Size(79, 37);
            this.btnAlarmReset.TabIndex = 8;
            this.btnAlarmReset.Text = "알람해제";
            this.btnAlarmReset.UseVisualStyleBackColor = true;
            this.btnAlarmReset.Click += new System.EventHandler(this.btnAlarmReset_Click);
            // 
            // txtAlarmID
            // 
            this.txtAlarmID.Location = new System.Drawing.Point(29, 36);
            this.txtAlarmID.Name = "txtAlarmID";
            this.txtAlarmID.Size = new System.Drawing.Size(100, 21);
            this.txtAlarmID.TabIndex = 7;
            // 
            // btnAlarmSet
            // 
            this.btnAlarmSet.Location = new System.Drawing.Point(172, 27);
            this.btnAlarmSet.Name = "btnAlarmSet";
            this.btnAlarmSet.Size = new System.Drawing.Size(79, 37);
            this.btnAlarmSet.TabIndex = 6;
            this.btnAlarmSet.Text = "알람보고";
            this.btnAlarmSet.UseVisualStyleBackColor = true;
            this.btnAlarmSet.Click += new System.EventHandler(this.btnAlarmSet_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1164, 496);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "DColl";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtOven_APD10);
            this.groupBox3.Controls.Add(this.txtOven_APD09);
            this.groupBox3.Controls.Add(this.txtOven_APD08);
            this.groupBox3.Controls.Add(this.txtOven_APD07);
            this.groupBox3.Controls.Add(this.txtOven_APD06);
            this.groupBox3.Controls.Add(this.txtOven_APD05);
            this.groupBox3.Controls.Add(this.txtOven_APD04);
            this.groupBox3.Controls.Add(this.txtOven_APD03);
            this.groupBox3.Controls.Add(this.txtOven_APD02);
            this.groupBox3.Controls.Add(this.txtOven_APD01);
            this.groupBox3.Location = new System.Drawing.Point(193, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(169, 433);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "OVEN";
            // 
            // txtOven_APD10
            // 
            this.txtOven_APD10.Location = new System.Drawing.Point(6, 263);
            this.txtOven_APD10.Name = "txtOven_APD10";
            this.txtOven_APD10.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD10.TabIndex = 13;
            this.txtOven_APD10.Text = "GLSID001";
            // 
            // txtOven_APD09
            // 
            this.txtOven_APD09.Location = new System.Drawing.Point(6, 236);
            this.txtOven_APD09.Name = "txtOven_APD09";
            this.txtOven_APD09.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD09.TabIndex = 12;
            this.txtOven_APD09.Text = "GLSID001";
            // 
            // txtOven_APD08
            // 
            this.txtOven_APD08.Location = new System.Drawing.Point(6, 209);
            this.txtOven_APD08.Name = "txtOven_APD08";
            this.txtOven_APD08.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD08.TabIndex = 11;
            this.txtOven_APD08.Text = "GLSID001";
            // 
            // txtOven_APD07
            // 
            this.txtOven_APD07.Location = new System.Drawing.Point(6, 182);
            this.txtOven_APD07.Name = "txtOven_APD07";
            this.txtOven_APD07.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD07.TabIndex = 10;
            this.txtOven_APD07.Text = "GLSID001";
            // 
            // txtOven_APD06
            // 
            this.txtOven_APD06.Location = new System.Drawing.Point(6, 155);
            this.txtOven_APD06.Name = "txtOven_APD06";
            this.txtOven_APD06.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD06.TabIndex = 9;
            this.txtOven_APD06.Text = "GLSID001";
            // 
            // txtOven_APD05
            // 
            this.txtOven_APD05.Location = new System.Drawing.Point(6, 128);
            this.txtOven_APD05.Name = "txtOven_APD05";
            this.txtOven_APD05.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD05.TabIndex = 8;
            this.txtOven_APD05.Text = "GLSID001";
            // 
            // txtOven_APD04
            // 
            this.txtOven_APD04.Location = new System.Drawing.Point(6, 101);
            this.txtOven_APD04.Name = "txtOven_APD04";
            this.txtOven_APD04.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD04.TabIndex = 7;
            this.txtOven_APD04.Text = "GLSID001";
            // 
            // txtOven_APD03
            // 
            this.txtOven_APD03.Location = new System.Drawing.Point(6, 74);
            this.txtOven_APD03.Name = "txtOven_APD03";
            this.txtOven_APD03.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD03.TabIndex = 6;
            this.txtOven_APD03.Text = "GLSID001";
            // 
            // txtOven_APD02
            // 
            this.txtOven_APD02.Location = new System.Drawing.Point(6, 47);
            this.txtOven_APD02.Name = "txtOven_APD02";
            this.txtOven_APD02.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD02.TabIndex = 5;
            this.txtOven_APD02.Text = "GLSID001";
            // 
            // txtOven_APD01
            // 
            this.txtOven_APD01.Location = new System.Drawing.Point(6, 20);
            this.txtOven_APD01.Name = "txtOven_APD01";
            this.txtOven_APD01.Size = new System.Drawing.Size(151, 21);
            this.txtOven_APD01.TabIndex = 3;
            this.txtOven_APD01.Text = "LOTID001";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtCLN_APD10);
            this.groupBox2.Controls.Add(this.txtCLN_APD09);
            this.groupBox2.Controls.Add(this.txtCLN_APD08);
            this.groupBox2.Controls.Add(this.txtCLN_APD07);
            this.groupBox2.Controls.Add(this.txtCLN_APD06);
            this.groupBox2.Controls.Add(this.txtCLN_APD05);
            this.groupBox2.Controls.Add(this.txtCLN_APD04);
            this.groupBox2.Controls.Add(this.txtCLN_APD03);
            this.groupBox2.Controls.Add(this.txtCLN_APD02);
            this.groupBox2.Controls.Add(this.txtCLN_APD01);
            this.groupBox2.Location = new System.Drawing.Point(8, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 433);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cleaner";
            // 
            // txtCLN_APD10
            // 
            this.txtCLN_APD10.Location = new System.Drawing.Point(6, 263);
            this.txtCLN_APD10.Name = "txtCLN_APD10";
            this.txtCLN_APD10.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD10.TabIndex = 13;
            this.txtCLN_APD10.Text = "GLSID001";
            // 
            // txtCLN_APD09
            // 
            this.txtCLN_APD09.Location = new System.Drawing.Point(6, 236);
            this.txtCLN_APD09.Name = "txtCLN_APD09";
            this.txtCLN_APD09.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD09.TabIndex = 12;
            this.txtCLN_APD09.Text = "GLSID001";
            // 
            // txtCLN_APD08
            // 
            this.txtCLN_APD08.Location = new System.Drawing.Point(6, 209);
            this.txtCLN_APD08.Name = "txtCLN_APD08";
            this.txtCLN_APD08.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD08.TabIndex = 11;
            this.txtCLN_APD08.Text = "GLSID001";
            // 
            // txtCLN_APD07
            // 
            this.txtCLN_APD07.Location = new System.Drawing.Point(6, 182);
            this.txtCLN_APD07.Name = "txtCLN_APD07";
            this.txtCLN_APD07.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD07.TabIndex = 10;
            this.txtCLN_APD07.Text = "GLSID001";
            // 
            // txtCLN_APD06
            // 
            this.txtCLN_APD06.Location = new System.Drawing.Point(6, 155);
            this.txtCLN_APD06.Name = "txtCLN_APD06";
            this.txtCLN_APD06.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD06.TabIndex = 9;
            this.txtCLN_APD06.Text = "GLSID001";
            // 
            // txtCLN_APD05
            // 
            this.txtCLN_APD05.Location = new System.Drawing.Point(6, 128);
            this.txtCLN_APD05.Name = "txtCLN_APD05";
            this.txtCLN_APD05.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD05.TabIndex = 8;
            this.txtCLN_APD05.Text = "GLSID001";
            // 
            // txtCLN_APD04
            // 
            this.txtCLN_APD04.Location = new System.Drawing.Point(6, 101);
            this.txtCLN_APD04.Name = "txtCLN_APD04";
            this.txtCLN_APD04.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD04.TabIndex = 7;
            this.txtCLN_APD04.Text = "GLSID001";
            // 
            // txtCLN_APD03
            // 
            this.txtCLN_APD03.Location = new System.Drawing.Point(6, 74);
            this.txtCLN_APD03.Name = "txtCLN_APD03";
            this.txtCLN_APD03.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD03.TabIndex = 6;
            this.txtCLN_APD03.Text = "GLSID001";
            // 
            // txtCLN_APD02
            // 
            this.txtCLN_APD02.Location = new System.Drawing.Point(6, 47);
            this.txtCLN_APD02.Name = "txtCLN_APD02";
            this.txtCLN_APD02.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD02.TabIndex = 5;
            this.txtCLN_APD02.Text = "GLSID001";
            // 
            // txtCLN_APD01
            // 
            this.txtCLN_APD01.Location = new System.Drawing.Point(6, 20);
            this.txtCLN_APD01.Name = "txtCLN_APD01";
            this.txtCLN_APD01.Size = new System.Drawing.Size(151, 21);
            this.txtCLN_APD01.TabIndex = 3;
            this.txtCLN_APD01.Text = "LOTID001";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button21);
            this.tabPage2.Controls.Add(this.button20);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.button15);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button14);
            this.tabPage2.Controls.Add(this.txtEqpPPID2);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.txtEqpPPID);
            this.tabPage2.Controls.Add(this.txthostppid);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1164, 496);
            this.tabPage2.TabIndex = 5;
            this.tabPage2.Text = "PPID";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button21.Location = new System.Drawing.Point(379, 174);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(132, 50);
            this.button21.TabIndex = 17;
            this.button21.Text = "삭제";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button20.Location = new System.Drawing.Point(379, 118);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(132, 50);
            this.button20.TabIndex = 16;
            this.button20.Text = "변경";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dataGridView2.Location = new System.Drawing.Point(655, 33);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(360, 457);
            this.dataGridView2.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 150F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 50F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button15.Location = new System.Drawing.Point(1021, 118);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(132, 50);
            this.button15.TabIndex = 14;
            this.button15.Text = "삭제";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button7.Location = new System.Drawing.Point(1021, 62);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(132, 50);
            this.button7.TabIndex = 13;
            this.button7.Text = "수정";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button14.Location = new System.Drawing.Point(1021, 6);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(132, 50);
            this.button14.TabIndex = 12;
            this.button14.Text = "추가";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // txtEqpPPID2
            // 
            this.txtEqpPPID2.Location = new System.Drawing.Point(864, 6);
            this.txtEqpPPID2.Name = "txtEqpPPID2";
            this.txtEqpPPID2.Size = new System.Drawing.Size(151, 21);
            this.txtEqpPPID2.TabIndex = 10;
            this.txtEqpPPID2.Text = "1";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Location = new System.Drawing.Point(517, 62);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(132, 50);
            this.button6.TabIndex = 9;
            this.button6.Text = "List갱신";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button5.Location = new System.Drawing.Point(379, 62);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 50);
            this.button5.TabIndex = 8;
            this.button5.Text = "추가";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // txtEqpPPID
            // 
            this.txtEqpPPID.Location = new System.Drawing.Point(360, 35);
            this.txtEqpPPID.Name = "txtEqpPPID";
            this.txtEqpPPID.Size = new System.Drawing.Size(151, 21);
            this.txtEqpPPID.TabIndex = 7;
            this.txtEqpPPID.Text = "1";
            // 
            // txthostppid
            // 
            this.txthostppid.Location = new System.Drawing.Point(360, 6);
            this.txthostppid.Name = "txthostppid";
            this.txthostppid.Size = new System.Drawing.Size(151, 21);
            this.txthostppid.TabIndex = 6;
            this.txthostppid.Text = "CIMTEST";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(8, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(346, 484);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.FillWeight = 200F;
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txtEQPPPIDMap03);
            this.tabPage3.Controls.Add(this.txtEQPPPIDMap02);
            this.tabPage3.Controls.Add(this.btnEQPPPID_ListUpdate);
            this.tabPage3.Controls.Add(this.txtEQPPPIDMap01);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.textBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1164, 496);
            this.tabPage3.TabIndex = 6;
            this.tabPage3.Text = "EQPPID";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtEQPPPIDMap03
            // 
            this.txtEQPPPIDMap03.Location = new System.Drawing.Point(20, 79);
            this.txtEQPPPIDMap03.MaxLength = 16;
            this.txtEQPPPIDMap03.Name = "txtEQPPPIDMap03";
            this.txtEQPPPIDMap03.Size = new System.Drawing.Size(121, 21);
            this.txtEQPPPIDMap03.TabIndex = 26;
            this.txtEQPPPIDMap03.Text = "0000000000000000";
            // 
            // txtEQPPPIDMap02
            // 
            this.txtEQPPPIDMap02.Location = new System.Drawing.Point(20, 52);
            this.txtEQPPPIDMap02.MaxLength = 16;
            this.txtEQPPPIDMap02.Name = "txtEQPPPIDMap02";
            this.txtEQPPPIDMap02.Size = new System.Drawing.Size(121, 21);
            this.txtEQPPPIDMap02.TabIndex = 25;
            this.txtEQPPPIDMap02.Text = "0000000000000000";
            // 
            // btnEQPPPID_ListUpdate
            // 
            this.btnEQPPPID_ListUpdate.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnEQPPPID_ListUpdate.Location = new System.Drawing.Point(196, 23);
            this.btnEQPPPID_ListUpdate.Name = "btnEQPPPID_ListUpdate";
            this.btnEQPPPID_ListUpdate.Size = new System.Drawing.Size(132, 50);
            this.btnEQPPPID_ListUpdate.TabIndex = 24;
            this.btnEQPPPID_ListUpdate.Text = "List 갱신";
            this.btnEQPPPID_ListUpdate.UseVisualStyleBackColor = true;
            this.btnEQPPPID_ListUpdate.Click += new System.EventHandler(this.btnEQPPPID_ListUpdate_Click);
            // 
            // txtEQPPPIDMap01
            // 
            this.txtEQPPPIDMap01.Location = new System.Drawing.Point(20, 25);
            this.txtEQPPPIDMap01.MaxLength = 16;
            this.txtEQPPPIDMap01.Name = "txtEQPPPIDMap01";
            this.txtEQPPPIDMap01.Size = new System.Drawing.Size(121, 21);
            this.txtEQPPPIDMap01.TabIndex = 21;
            this.txtEQPPPIDMap01.Text = "1111111111111111";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dataGridView3.Location = new System.Drawing.Point(776, 33);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 23;
            this.dataGridView3.Size = new System.Drawing.Size(244, 457);
            this.dataGridView3.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 150F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Column1";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 50F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Column2";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button8.Location = new System.Drawing.Point(1026, 118);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(132, 50);
            this.button8.TabIndex = 19;
            this.button8.Text = "삭제";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button9.Location = new System.Drawing.Point(1026, 62);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(132, 50);
            this.button9.TabIndex = 18;
            this.button9.Text = "수정";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button10.Location = new System.Drawing.Point(1026, 6);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(132, 50);
            this.button10.TabIndex = 17;
            this.button10.Text = "추가";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(869, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(151, 21);
            this.textBox1.TabIndex = 16;
            this.textBox1.Text = "1";
            // 
            // tmrUpdate
            // 
            this.tmrUpdate.Tick += new System.EventHandler(this.tmrUpdate_Tick);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.LightGray;
            this.button25.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button25.Location = new System.Drawing.Point(544, 397);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(120, 45);
            this.button25.TabIndex = 37;
            this.button25.Text = "TEST";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(544, 370);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 21);
            this.textBox2.TabIndex = 38;
            this.textBox2.Text = "-139";
            // 
            // frmSimulationTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 572);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmSimulationTest";
            this.Text = "frmSimulationTest";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.page1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabAlarm.ResumeLayout(false);
            this.tabAlarm.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage page1;
        private System.Windows.Forms.TabPage tabAlarm;
        private System.Windows.Forms.Button btnAlarmSet;
        private System.Windows.Forms.Timer tmrUpdate;
        private System.Windows.Forms.Button btnFI01_In;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtGlassScrap_LOTID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnGLSScrap;
        private System.Windows.Forms.TextBox txtGlassScrap_SlotID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtSlotID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLOTID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtOven_APD10;
        private System.Windows.Forms.TextBox txtOven_APD09;
        private System.Windows.Forms.TextBox txtOven_APD08;
        private System.Windows.Forms.TextBox txtOven_APD07;
        private System.Windows.Forms.TextBox txtOven_APD06;
        private System.Windows.Forms.TextBox txtOven_APD05;
        private System.Windows.Forms.TextBox txtOven_APD04;
        private System.Windows.Forms.TextBox txtOven_APD03;
        private System.Windows.Forms.TextBox txtOven_APD02;
        private System.Windows.Forms.TextBox txtOven_APD01;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtCLN_APD10;
        private System.Windows.Forms.TextBox txtCLN_APD09;
        private System.Windows.Forms.TextBox txtCLN_APD08;
        private System.Windows.Forms.TextBox txtCLN_APD07;
        private System.Windows.Forms.TextBox txtCLN_APD06;
        private System.Windows.Forms.TextBox txtCLN_APD05;
        private System.Windows.Forms.TextBox txtCLN_APD04;
        private System.Windows.Forms.TextBox txtCLN_APD03;
        private System.Windows.Forms.TextBox txtCLN_APD02;
        private System.Windows.Forms.TextBox txtCLN_APD01;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtEqpPPID;
        private System.Windows.Forms.TextBox txthostppid;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox txtEqpPPID2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtST01_SlotID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtST01_HostPPID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtST01_GLSID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnST01_O;
        private System.Windows.Forms.TextBox txtST01_LOTID;
        private System.Windows.Forms.Button btnST01_I;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnIS01_O;
        private System.Windows.Forms.Button btnIS01_In;
        private System.Windows.Forms.Button btnDM01_O;
        private System.Windows.Forms.Button btnDM01_In;
        private System.Windows.Forms.Button btnLM01_O;
        private System.Windows.Forms.Button btnLM01_In;
        private System.Windows.Forms.Button btnFT02_O;
        private System.Windows.Forms.Button btnFT02_In;
        private System.Windows.Forms.Button btnAL01_O;
        private System.Windows.Forms.Button btnAL01_In;
        private System.Windows.Forms.Button btnFT01_O;
        private System.Windows.Forms.Button btnFT01_In;
        private System.Windows.Forms.Button btnFI02_Out;
        private System.Windows.Forms.Button btnFI02_In;
        private System.Windows.Forms.Button btnFI01_Out;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtST01_LotEnd;
        private System.Windows.Forms.TextBox txtST01_LOTStart;
        private System.Windows.Forms.TextBox txtFilmCount;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnGLSUnScrap;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnFilmUnScrap;
        private System.Windows.Forms.TextBox txtFilmScrap_SlotID;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtFilmScrap_LOTID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnFilmScrap;
        private System.Windows.Forms.TextBox txtFilmScrap_UnitID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtGlassScrap_UnitID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnProcessDataCheck;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnEQPPPID_ListUpdate;
        private System.Windows.Forms.TextBox txtEQPPPIDMap01;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtEQPPPIDMap03;
        private System.Windows.Forms.TextBox txtEQPPPIDMap02;
        private System.Windows.Forms.Button btnAlarmReset;
        private System.Windows.Forms.TextBox txtAlarmID;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button25;

    }
}