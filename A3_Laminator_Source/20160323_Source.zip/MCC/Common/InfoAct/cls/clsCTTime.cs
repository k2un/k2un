﻿using System;
using System.Text;
using System.Collections;

namespace InfoAct
{
    class clsCTTime
    {
        //CT 관련 속성
        public long CTCheckTime = 0;            //CT Check시작 시간
        public string HostWaitSF = "";          //Host로부터 기다리게될 SF의 이름(Conversation TimeOut시 사용)
        public string KeyThis = "";             //KEY

    }
}
