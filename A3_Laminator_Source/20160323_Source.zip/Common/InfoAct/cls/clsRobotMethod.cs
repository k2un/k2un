﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InfoAct
{
    public class clsRobotMethod
    {
        //CurrGLS 개체등록 및 가져오기
        #region "CurrGLS"

        #endregion
    }
}
