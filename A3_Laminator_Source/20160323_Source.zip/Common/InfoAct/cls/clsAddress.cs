﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfoAct
{
    public class clsAddress
    {


        #region Singleton
        public static readonly clsAddress Instance = new clsAddress();
        #endregion

        public clsAddress()
        {

        }
    }
}
