using System;
using System.Collections.Generic;
using System.Text;

namespace InfoAct
{
    public class clsOPCallOverWrite
    {
        public int intOPCallType = 0;       //Operator Call Type
        public int intPortID = 0;           //ó���� Port��ȣ
        public string strFromSF = "";       //�߻� Stream Function(Conversaction or Validation Error �� ���) 
        public string strHostMsg = "";      //Host By LOT Cancel�� ��� Host Message
    }
}
