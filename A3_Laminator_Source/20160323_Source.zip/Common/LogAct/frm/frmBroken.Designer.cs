﻿namespace LogAct
{
    partial class frmBroken
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum2 = new System.Windows.Forms.Label();
            this.lblPrevious = new System.Windows.Forms.Label();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAlarmDisplay = new System.Windows.Forms.Button();
            this.lblAlarmDateTo = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAlarmDateFrom = new System.Windows.Forms.Label();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblNum10 = new System.Windows.Forms.Label();
            this.lblNum9 = new System.Windows.Forms.Label();
            this.lblNum8 = new System.Windows.Forms.Label();
            this.lblNum7 = new System.Windows.Forms.Label();
            this.lblNext = new System.Windows.Forms.Label();
            this.lblNum6 = new System.Windows.Forms.Label();
            this.lblNum5 = new System.Windows.Forms.Label();
            this.lblNum4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum2.Location = new System.Drawing.Point(300, 654);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(11, 12);
            this.lblNum2.TabIndex = 47;
            this.lblNum2.Tag = "2";
            this.lblNum2.Text = "2";
            // 
            // lblPrevious
            // 
            this.lblPrevious.AutoSize = true;
            this.lblPrevious.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblPrevious.Location = new System.Drawing.Point(206, 654);
            this.lblPrevious.Name = "lblPrevious";
            this.lblPrevious.Size = new System.Drawing.Size(54, 12);
            this.lblPrevious.TabIndex = 48;
            this.lblPrevious.Text = "Previous";
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum1.Location = new System.Drawing.Point(283, 654);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(11, 12);
            this.lblNum1.TabIndex = 38;
            this.lblNum1.Tag = "1";
            this.lblNum1.Text = "1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label13.Location = new System.Drawing.Point(266, 654);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 12);
            this.label13.TabIndex = 39;
            this.label13.Text = "<";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(764, 629);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(134, 50);
            this.btnExit.TabIndex = 36;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(624, 629);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(134, 50);
            this.btnDelete.TabIndex = 35;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnAlarmDisplay
            // 
            this.btnAlarmDisplay.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAlarmDisplay.Location = new System.Drawing.Point(735, 11);
            this.btnAlarmDisplay.Name = "btnAlarmDisplay";
            this.btnAlarmDisplay.Size = new System.Drawing.Size(130, 44);
            this.btnAlarmDisplay.TabIndex = 5;
            this.btnAlarmDisplay.Text = "DISPLAY";
            this.btnAlarmDisplay.UseVisualStyleBackColor = true;
            // 
            // lblAlarmDateTo
            // 
            this.lblAlarmDateTo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAlarmDateTo.BackColor = System.Drawing.Color.White;
            this.lblAlarmDateTo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAlarmDateTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlarmDateTo.Location = new System.Drawing.Point(519, 20);
            this.lblAlarmDateTo.Name = "lblAlarmDateTo";
            this.lblAlarmDateTo.Size = new System.Drawing.Size(121, 27);
            this.lblAlarmDateTo.TabIndex = 4;
            this.lblAlarmDateTo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(470, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "To";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(176, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Date  From";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAlarmDateFrom
            // 
            this.lblAlarmDateFrom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAlarmDateFrom.BackColor = System.Drawing.Color.White;
            this.lblAlarmDateFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAlarmDateFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlarmDateFrom.Location = new System.Drawing.Point(342, 20);
            this.lblAlarmDateFrom.Name = "lblAlarmDateFrom";
            this.lblAlarmDateFrom.Size = new System.Drawing.Size(125, 27);
            this.lblAlarmDateFrom.TabIndex = 1;
            this.lblAlarmDateFrom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum3.Location = new System.Drawing.Point(317, 654);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(11, 12);
            this.lblNum3.TabIndex = 50;
            this.lblNum3.Tag = "3";
            this.lblNum3.Text = "3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label14.Location = new System.Drawing.Point(453, 654);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 12);
            this.label14.TabIndex = 41;
            this.label14.Text = ">";
            // 
            // lblNum10
            // 
            this.lblNum10.AutoSize = true;
            this.lblNum10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum10.Location = new System.Drawing.Point(436, 654);
            this.lblNum10.Name = "lblNum10";
            this.lblNum10.Size = new System.Drawing.Size(17, 12);
            this.lblNum10.TabIndex = 42;
            this.lblNum10.Tag = "10";
            this.lblNum10.Text = "10";
            // 
            // lblNum9
            // 
            this.lblNum9.AutoSize = true;
            this.lblNum9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum9.Location = new System.Drawing.Point(419, 654);
            this.lblNum9.Name = "lblNum9";
            this.lblNum9.Size = new System.Drawing.Size(11, 12);
            this.lblNum9.TabIndex = 37;
            this.lblNum9.Tag = "9";
            this.lblNum9.Text = "9";
            // 
            // lblNum8
            // 
            this.lblNum8.AutoSize = true;
            this.lblNum8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum8.Location = new System.Drawing.Point(402, 654);
            this.lblNum8.Name = "lblNum8";
            this.lblNum8.Size = new System.Drawing.Size(11, 12);
            this.lblNum8.TabIndex = 45;
            this.lblNum8.Tag = "8";
            this.lblNum8.Text = "8";
            // 
            // lblNum7
            // 
            this.lblNum7.AutoSize = true;
            this.lblNum7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum7.Location = new System.Drawing.Point(385, 654);
            this.lblNum7.Name = "lblNum7";
            this.lblNum7.Size = new System.Drawing.Size(11, 12);
            this.lblNum7.TabIndex = 46;
            this.lblNum7.Tag = "7";
            this.lblNum7.Text = "7";
            // 
            // lblNext
            // 
            this.lblNext.AutoSize = true;
            this.lblNext.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNext.Location = new System.Drawing.Point(472, 654);
            this.lblNext.Name = "lblNext";
            this.lblNext.Size = new System.Drawing.Size(31, 12);
            this.lblNext.TabIndex = 40;
            this.lblNext.Text = "Next";
            // 
            // lblNum6
            // 
            this.lblNum6.AutoSize = true;
            this.lblNum6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum6.Location = new System.Drawing.Point(368, 654);
            this.lblNum6.Name = "lblNum6";
            this.lblNum6.Size = new System.Drawing.Size(11, 12);
            this.lblNum6.TabIndex = 43;
            this.lblNum6.Tag = "6";
            this.lblNum6.Text = "6";
            // 
            // lblNum5
            // 
            this.lblNum5.AutoSize = true;
            this.lblNum5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum5.Location = new System.Drawing.Point(351, 654);
            this.lblNum5.Name = "lblNum5";
            this.lblNum5.Size = new System.Drawing.Size(11, 12);
            this.lblNum5.TabIndex = 44;
            this.lblNum5.Tag = "5";
            this.lblNum5.Text = "5";
            // 
            // lblNum4
            // 
            this.lblNum4.AutoSize = true;
            this.lblNum4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNum4.Location = new System.Drawing.Point(334, 654);
            this.lblNum4.Name = "lblNum4";
            this.lblNum4.Size = new System.Drawing.Size(11, 12);
            this.lblNum4.TabIndex = 49;
            this.lblNum4.Tag = "4";
            this.lblNum4.Text = "4";
            // 
            // frmBroken
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(791, 538);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblPrevious);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblNum10);
            this.Controls.Add(this.lblNum9);
            this.Controls.Add(this.lblNum8);
            this.Controls.Add(this.lblNum7);
            this.Controls.Add(this.lblNext);
            this.Controls.Add(this.lblNum6);
            this.Controls.Add(this.lblNum5);
            this.Controls.Add(this.lblNum4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmBroken";
            this.Text = "frmBroken";
            this.Controls.SetChildIndex(this.lblNum4, 0);
            this.Controls.SetChildIndex(this.lblNum5, 0);
            this.Controls.SetChildIndex(this.lblNum6, 0);
            this.Controls.SetChildIndex(this.lblNext, 0);
            this.Controls.SetChildIndex(this.lblNum7, 0);
            this.Controls.SetChildIndex(this.lblNum8, 0);
            this.Controls.SetChildIndex(this.lblNum9, 0);
            this.Controls.SetChildIndex(this.lblNum10, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.lblNum3, 0);
            this.Controls.SetChildIndex(this.btnDelete, 0);
            this.Controls.SetChildIndex(this.btnExit, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.lblNum1, 0);
            this.Controls.SetChildIndex(this.lblPrevious, 0);
            this.Controls.SetChildIndex(this.lblNum2, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.Label lblPrevious;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblNum10;
        private System.Windows.Forms.Label lblNum9;
        private System.Windows.Forms.Label lblNum8;
        private System.Windows.Forms.Label lblNum7;
        private System.Windows.Forms.Label lblNext;
        private System.Windows.Forms.Label lblNum6;
        private System.Windows.Forms.Label lblNum5;
        private System.Windows.Forms.Label lblNum4;
        private System.Windows.Forms.Button btnAlarmDisplay;
        private System.Windows.Forms.Label lblAlarmDateTo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblAlarmDateFrom;
    }
}