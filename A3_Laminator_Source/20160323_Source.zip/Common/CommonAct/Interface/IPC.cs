﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonAct
{
    public interface IPC : IOpenClose, IPCCommand 
    {
    }
}
