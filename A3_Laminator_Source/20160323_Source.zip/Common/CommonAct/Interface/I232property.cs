﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonAct
{
    public interface I232property
    {
        string proCommSetting
        {
            get;
            set;
        }
        string proCommPort
        {
            get;
            set;
        }
    }
}
