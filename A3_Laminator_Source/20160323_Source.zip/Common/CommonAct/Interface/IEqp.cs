﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonAct
{
    public interface IEqp : IOpenClose, IPCCommand, IPLCCommand
    {
    }
}
